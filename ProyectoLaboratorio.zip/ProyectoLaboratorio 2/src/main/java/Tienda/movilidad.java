package Tienda;

public class movilidad extends ObjetosMejoras{

    public movilidad() {
        this.precio=500;
        this.nombre="Movilidad";
        this.descripcion="otorga al personaje 1 casilla adicional de movimiento";
        this.cantidad=0;
    }
}
