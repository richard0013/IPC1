/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tienda;

/**
 *
 * @author user
 */
public class Elixir extends ObjetosMejoras {

    public Elixir() {
        this.precio=25;
        this.objetos= true;
        this.descripcion="cura 50 de vida";
        this.nombre="Elixir verde";
        this.cantidad=0;
    }
    
}
