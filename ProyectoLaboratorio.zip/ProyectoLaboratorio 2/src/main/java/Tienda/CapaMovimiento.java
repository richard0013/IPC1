/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tienda;

/**
 *
 * @author user
 */
public class CapaMovimiento extends ObjetosMejoras {

    public CapaMovimiento() {
        this.precio=75;
        this.objetos=true;
        this.descripcion="mueve al personaje una casilla a su alrededor";
        this.nombre="Capa Movimiento";
        this.cantidad=0;
    }
    
}
