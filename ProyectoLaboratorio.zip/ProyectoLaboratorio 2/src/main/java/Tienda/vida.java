package Tienda;

public class vida extends ObjetosMejoras {

    public vida() {
        this.precio=80;
        this.nombre="Vida";
        this.descripcion="otorga al personaje 50 de vida máxima";
        this.cantidad=0;
    }
}
