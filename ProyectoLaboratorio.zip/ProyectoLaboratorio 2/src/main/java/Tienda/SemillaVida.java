/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tienda;

/**
 *
 * @author user
 */
public class SemillaVida extends ObjetosMejoras {

    public SemillaVida() {
        this.precio=50;
        this.objetos= true;
        this.nombre="Semilla de la Vida";
        this.descripcion="resucita a uno de los personajes";
        this.cantidad=0;
    }
    
}
