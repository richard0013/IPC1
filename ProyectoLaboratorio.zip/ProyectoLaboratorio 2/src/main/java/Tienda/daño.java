package Tienda;

public class daño extends ObjetosMejoras{

    public daño() {
        this.precio=125;
        this.nombre="Daño";
        this.descripcion="otorga al personaje 10 de daño de ataque";
        this.cantidad=0;
    }
}
