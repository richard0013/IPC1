
package principal;


import principal.Juego.CreadorTableros;
import principal.Juego.Juego;
import principal.Juego.Tablero;
import principal.common.LectorOpciones;

import java.awt.*;
import java.util.Scanner;



public class IniciarJuego {
    public static void main(String[] args) {
        LanzadorJuego juego= new LanzadorJuego();
    }

    
}

    

