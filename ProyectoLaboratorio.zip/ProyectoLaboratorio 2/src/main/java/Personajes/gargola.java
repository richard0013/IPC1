/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Personajes;

/**
 *
 * @author user
 * GARGOLA = R
 */
public class gargola extends Personajes {

    public gargola() {
        this.vuela=true;
        this.vida=150;
        this.dano=100;
        this.movimientoMaximo=3;
        this.dibujo=RED+"R";
        this.nombre= "Gargola";
        this.Ataque="lanza una bola de fuego en una línea en un rango de dos cuadros, que impacta con el primer personaje del jugador que encuentre";
    }
    
}
