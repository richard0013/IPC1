/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Personajes;

/**
 *
 * @author user
 */
public class dragon extends Personajes {

    public dragon() {
        this.vuela=true;
        this.vida=250;
        this.dano=75;
        this.movimientoMaximo=3;
        this.dibujo=PURPLE+"D";
        this.precio=200;
        this.nombre="Dragon";
        this.Ataque="en línea y en un rango de dos cuadros a todo lo que esté en dicho rango";
    }
    
}
