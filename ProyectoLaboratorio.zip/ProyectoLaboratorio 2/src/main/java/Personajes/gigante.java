/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Personajes;

/**
 *
 * @author user
 */
public class gigante extends Personajes {

    public gigante() {
        this.vuela=false;
        this.vida=350;
        this.dano=56;
        this.movimientoMaximo=1;
        this.dibujo=PURPLE+"G";
        this.precio=200;
        this.nombre="Gigante";
        this.Ataque="golpea con su brazo, lo que le hace daño a todos los enemigos/obstáculos en una línea en un rango de 3 cuadros";
    }
    
}
