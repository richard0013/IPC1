
package Personajes;

/**
 *
 GARGOLA = R
 */
public class ogro extends Personajes {

    public ogro() {
        this.vuela=false;
        this.vida=300;
        this.dano=50;
        this.movimientoMaximo=1;
        this.dibujo=RED+"0";
        this.nombre="Ogro";
        this.Ataque="golpea con su bastón a un punto en un rango de un cuadro a su alrededor";
    }    
}
