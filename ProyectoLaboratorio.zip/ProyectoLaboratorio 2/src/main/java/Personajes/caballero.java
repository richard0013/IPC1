/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Personajes;

/**
 *
 * @author user
 */
public class caballero extends Personajes {

    public caballero() {
        this.vuela=false;
        this.vida=300;
        this.dano=45;
        this.movimientoMaximo=1;
        this.dibujo=PURPLE+"C";
        this.precio=200;
        this.nombre= "Caballero";
        this.Ataque= "golpea con su espada a todos a su alrededor";
    }
    
    
    
}
