/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Personajes;

/**
 *
 * @author user
 * CANCERBERO = N
 */
public class cancerbero extends Personajes {

    public cancerbero() {
        this.vuela=false;
        this.vida=400;
        this.dano=45;
        this.movimientoMaximo=1;
        this.dibujo=RED+"N";
        this.nombre="Cancerbero";
        this.Ataque="incendia todo a su alrededor, en un rango de un cuadro";
    }
    
}
